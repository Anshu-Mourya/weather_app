import CloseIcon from "./close.gif";
import logo from "./logo.svg";
import RainCloudIcon from "./rain-cloud.gif";
import SearchIcon from "./search.svg";
import DirectionIcon from "./direction.png";


export { CloseIcon, logo, RainCloudIcon, SearchIcon, DirectionIcon };